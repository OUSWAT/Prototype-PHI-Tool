'use strict';
GLOBAL.javascript = {};
GLOBAL.javascript.util = require('javascript.util');
var jsts = require('./lib/jsts');
module.exports = jsts
