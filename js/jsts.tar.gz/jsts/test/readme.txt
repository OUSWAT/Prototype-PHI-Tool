Note that SpecRunner.html uses AJAX to fetch test data which in general requires it to be published on a web server before running.
