/**
 * namespace
 */
jsts.vs = {
    
};